setwd("/Users/timalijayasinghe/Desktop/IT24101116_Lab08")
data<-read.table("Exercise - LaptopsWeights.txt", header = TRUE)
attach(data)

#Q1
popmn<-mean(Weight.kg.)
popmn
popvar<-var(Weight.kg.)
popsd<-sd(Weight.kg.)
popsd


#Q2
sample<-c()
n<-c()

for(i in 1:25){
  s<-sample(Weight.kg.,6,replace =TRUE)
  sample<-cbind(sample,s)
  n<-c(n,paste('s',i))
}

colnames(sample)=n

s.means<-apply(sample,2,mean)
s.means
s.sd<-apply(sample,2,sd)
s.sd


#Q3
samplemean<-mean(s.means)
popmn
samplesd<-sd(s.sd)
samplemean


truesd =popsd/6
samplesd
